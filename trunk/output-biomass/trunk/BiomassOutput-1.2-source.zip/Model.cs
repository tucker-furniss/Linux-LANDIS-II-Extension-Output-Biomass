namespace Landis.Output.Biomass
{
    internal static class Model
    {
        internal static PlugIns.ICore Core;
    }
}
