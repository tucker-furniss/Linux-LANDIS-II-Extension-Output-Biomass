using Edu.Wisc.Forest.Flel.Util;
using Landis.Species;
using System.Collections.Generic;

namespace Landis.Output.Biomass
{
    /// <summary>
    /// The parameters for the plug-in.
    /// </summary>
    public class Parameters
        : IParameters
    {
        private int timestep;
        private IEnumerable<ISpecies> selectedSpecies;
        private string speciesMapNames;
        private SelectedDeadPools selectedPools;
        private string poolMapNames;

        //---------------------------------------------------------------------

        public int Timestep
        {
            get {
                return timestep;
            }
            set {
                //if (value != null)
                if (value < 0)
                    throw new InputValueException(value.ToString(), "Value must be = or > 0");
                timestep = value;
            }
        }

        //---------------------------------------------------------------------

        public IEnumerable<ISpecies> SelectedSpecies
        {
            get {
                return selectedSpecies;
            }
            set {
                selectedSpecies = value;
            }
        }

        //---------------------------------------------------------------------

        public string SpeciesMapNames
        {
            get {
                return speciesMapNames;
            }
            set {
                //if (value != null) {
                    Biomass.SpeciesMapNames.CheckTemplateVars(value);
                //}
                speciesMapNames = value;
            }
        }

        //---------------------------------------------------------------------

        public SelectedDeadPools SelectedPools
        {
            get {
                return selectedPools;
            }
            set {
                //VerifyPoolsAndMapNames(value, poolMapNames);
                selectedPools = value;
            }
        }

        //---------------------------------------------------------------------

        public string PoolMapNames
        {
            get {
                return poolMapNames;
            }
            set {
                //VerifyPoolsAndMapNames(selectedPools, value);
                poolMapNames = value;
            }
        }

        //---------------------------------------------------------------------
/*
        public Parameters(int                   timestep,
                          IEnumerable<ISpecies> selectedSpecies,
                          string                speciesMapNames,
                          SelectedDeadPools     selectedPools,
                          string                poolMapNames)
        {
            this.timestep = timestep;
            this.selectedSpecies = selectedSpecies;
            this.speciesMapNames = speciesMapNames;
            this.selectedPools = selectedPools;
            this.poolMapNames = poolMapNames;
        }*/
        
        public Parameters()
        {
        }
        //---------------------------------------------------------------------

        //private void VerifyPoolsAndMapNames(InputValue<SelectedDeadPools> pools,
        //                                    InputValue<string>            mapNames)
        private void VerifyPoolsAndMapNames(SelectedDeadPools pools,
                                            string            mapNames)
        {
            //if (pools == null || mapNames == null)
            //    return;
            Biomass.PoolMapNames.CheckTemplateVars(mapNames, pools);
        }
    }
}
