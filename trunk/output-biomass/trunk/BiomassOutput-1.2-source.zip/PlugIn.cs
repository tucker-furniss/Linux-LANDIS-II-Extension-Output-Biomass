using Edu.Wisc.Forest.Flel.Util;

using Landis.Biomass.Succession;
using Landis.Biomass;
using Landis.Landscape;
using Landis.RasterIO;
using Landis.Species;
using Landis.Ecoregions;

using System;
using System.Collections.Generic;
using System.IO;


namespace Landis.Output.Biomass
{
    public class PlugIn
        : Landis.PlugIns.PlugIn
    {
        //private PlugIns.ICore Model.Core;
        private IEnumerable<ISpecies> selectedSpecies;
        private string speciesMapNameTemplate;
        private SelectedDeadPools selectedPools;
        private string poolMapNameTemplate;
        private ILandscapeCohorts cohorts;
        private StreamWriter log;


        //---------------------------------------------------------------------

        public PlugIn()
            : base("Output Biomass", new PlugIns.PlugInType("output"))
        {
        }

        //---------------------------------------------------------------------

        public override void Initialize(string        dataFile,
                                        PlugIns.ICore modelCore)
        {
            Model.Core = modelCore;

            ParametersParser parser = new ParametersParser(Model.Core.Species);
            IParameters parameters = Data.Load<IParameters>(dataFile,
                                                            parser);

            Timestep = parameters.Timestep;
            this.selectedSpecies = parameters.SelectedSpecies;
            this.speciesMapNameTemplate = parameters.SpeciesMapNames;
            this.selectedPools = parameters.SelectedPools;
            this.poolMapNameTemplate = parameters.PoolMapNames;

            cohorts = Model.Core.SuccessionCohorts as ILandscapeCohorts;
            if (cohorts == null)
                throw new ApplicationException("Error: Cohorts don't support biomass interface");
                
            string summaryLog = "biomass-outputs-summary.csv";

            //open log file and write header
            UI.WriteLine("Opening biomass log file \"{0}\" ...", summaryLog);
            log = Data.CreateTextFile(summaryLog);
            log.AutoFlush = true;
            
            //include a column for each species in the species dictionary
            string species_header_names = "";
            int i = 0;
            for (i = 0; i < Model.Core.Species.Count; i++) {
                species_header_names += "," + Model.Core.Species[i].Name;
            }
                
            log.WriteLine("Time,Ecoregion{0}", species_header_names);


        }

        //---------------------------------------------------------------------

        public override void Run()
        {
            WriteMapForAllSpecies();
            
            if (selectedSpecies != null)
                WriteSpeciesMaps();

            if (selectedPools != SelectedDeadPools.None)
                WritePoolMaps();
                
            int[,] totalAGB  = new int[Model.Core.Ecoregions.Count, Model.Core.Species.Count];
            int[] sitePerEcoregion = new int[Model.Core.Ecoregions.Count];
            
            foreach (ActiveSite site in Model.Core.Landscape)
            {
                IEcoregion ecoregion = Model.Core.Ecoregion[site];
                
                foreach (ISpecies species in Model.Core.Species) 
                {
                    totalAGB[ecoregion.Index, species.Index] += ComputeSpeciesBiomass(cohorts[site][species]);
                }
                
                sitePerEcoregion[ecoregion.Index]++;
            }    
            

            foreach (IEcoregion ecoregion in Model.Core.Ecoregions)
            {

                string species_string = "";
                foreach (ISpecies species in Model.Core.Species) 
                {
                    double avgAGB = (double) totalAGB[ecoregion.Index, species.Index] / (double) sitePerEcoregion[ecoregion.Index];
                    species_string += ", " + avgAGB;
                }
                
                if(sitePerEcoregion[ecoregion.Index] > 0)
                    log.WriteLine("{0},{1}{2}",
                            Model.Core.CurrentTime, 
                            ecoregion.Name, 
                            species_string);
            }

        }

        //---------------------------------------------------------------------

        private void WriteSpeciesMaps()
        {
            foreach (ISpecies species in selectedSpecies) {
                IOutputRaster<BiomassPixel> map = CreateMap(MakeSpeciesMapName(species.Name));
                using (map) {
                    BiomassPixel pixel = new BiomassPixel();
                    foreach (Site site in Model.Core.Landscape.AllSites) {
                        if (site.IsActive)
                            pixel.Band0 = (ushort) Math.Round((double) ComputeSpeciesBiomass(cohorts[site][species]) / 100.0);
                        else
                            pixel.Band0 = 0;
                        map.WritePixel(pixel);
                    }
                }
            }

        }

        //---------------------------------------------------------------------

        private void WriteMapForAllSpecies()
        {
            // Biomass map for all species
            IOutputRaster<BiomassPixel> map = CreateMap(MakeSpeciesMapName("TotalBiomass"));
            using (map) {
                BiomassPixel pixel = new BiomassPixel();
                foreach (Site site in Model.Core.Landscape.AllSites) {
                    if (site.IsActive)
                        pixel.Band0 = (ushort) Math.Round((double) ComputeTotalBiomass(cohorts[site]) / 100.0);
                    else
                        pixel.Band0 = 0;
                    map.WritePixel(pixel);
                }
            }
        }

        //---------------------------------------------------------------------

        private string MakeSpeciesMapName(string species)
        {
            return SpeciesMapNames.ReplaceTemplateVars(speciesMapNameTemplate,
                                                       species,
                                                       Model.Core.CurrentTime);
        }

        //---------------------------------------------------------------------

        private IOutputRaster<BiomassPixel> CreateMap(string path)
        {
            UI.WriteLine("Writing biomass map to {0} ...", path);
            return Model.Core.CreateRaster<BiomassPixel>(path,
                                                        Model.Core.Landscape.Dimensions,
                                                        Model.Core.LandscapeMapMetadata);
        }

        //---------------------------------------------------------------------

        private void WritePoolMaps()
        {
            if ((selectedPools & SelectedDeadPools.Woody) != 0)
                WritePoolMap("woody", SiteVars.WoodyDebris);

            if ((selectedPools & SelectedDeadPools.NonWoody) != 0)
                WritePoolMap("non-woody", SiteVars.Litter);
                
        }

        //---------------------------------------------------------------------

        private void WritePoolMap(string         poolName,
                                  ISiteVar<Pool> poolSiteVar)
        {
            string path = PoolMapNames.ReplaceTemplateVars(poolMapNameTemplate,
                                                           poolName,
                                                           Model.Core.CurrentTime);
            if(poolSiteVar != null)
            {
                IOutputRaster<BiomassPixel> map = CreateMap(path);
                using (map) {
                    BiomassPixel pixel = new BiomassPixel();
                    foreach (Site site in Model.Core.Landscape.AllSites) {
                        if (site.IsActive)
                            pixel.Band0 = (ushort) ((float) poolSiteVar[site].Mass / 100.0);
                        else
                            pixel.Band0 = 0;
                        map.WritePixel(pixel);
                    }
                }
            }
        }
        //---------------------------------------------------------------------
        private static int ComputeSpeciesBiomass(ISpeciesCohorts cohorts)
        {
            int total = 0;
            if (cohorts != null)
                foreach (ICohort cohort in cohorts)
                    total += cohort.Biomass;
            return total;
        }

        //---------------------------------------------------------------------

        private static int ComputeTotalBiomass(ISiteCohorts cohorts)
        {
            int total = 0;
            if (cohorts != null)
                foreach (ISpeciesCohorts speciesCohorts in cohorts)
                {
                    //int sppBiomass = ComputeSpeciesBiomass(speciesCohorts);
                    total += ComputeSpeciesBiomass(speciesCohorts);
                }
            return total;
        }
    }
}
