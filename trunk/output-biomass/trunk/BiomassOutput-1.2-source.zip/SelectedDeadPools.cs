using System;

namespace Landis.Output.Biomass
{
    [FlagsAttribute]
    public enum SelectedDeadPools
    {
        None =     0x00,
        Woody =    0x01,
        NonWoody = 0x02
    }
}
